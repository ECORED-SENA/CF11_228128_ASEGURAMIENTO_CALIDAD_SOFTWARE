function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6i3rs1DEojI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

